from django.contrib import admin
from django.utils.html import format_html
from .models import (
    HomePage, AboutPage, Service, Blog,
    Career, Lead, Stakeholder, Resource,
    ContactInfo, Feature
)


# ✅ Helper Function for Image Thumbnails
def image_preview(obj):
    if obj and getattr(obj, 'image', None):
        return format_html(f'<img src="{obj.image.url}" width="100" style="border-radius:8px;" />')
    return "No Image"


# 🏠 Home Page Admin
@admin.register(HomePage)
class HomePageAdmin(admin.ModelAdmin):
    list_display = ('hero_title',)
    fieldsets = (
        ('Hero Section', {
            'fields': ('hero_title', 'hero_subtitle', 'hero_image'),
        }),
        ('Highlights', {
            'fields': ('highlight_1', 'highlight_2', 'highlight_3'),
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description', 'meta_keywords'),
        }),
    )


# ℹ️ About Page Admin
@admin.register(AboutPage)
class AboutPageAdmin(admin.ModelAdmin):
    list_display = ('title',)
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return format_html(f'<img src="{obj.image.url}" width="100" style="border-radius:8px;" />')
        return "No Image"

    fieldsets = (
        ('About Section', {
            'fields': ('title', 'mission', 'vision', 'description', 'image', 'image_preview'),
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description', 'meta_keywords'),
        }),
    )


# 💼 Services Admin
@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'short_description', 'icon_preview')
    search_fields = ('name',)
    readonly_fields = ('icon_preview',)

    def icon_preview(self, obj):
        if obj.icon:
            return format_html(f'<img src="{obj.icon.url}" width="80" style="border-radius:8px;" />')
        return "No Icon"

    fieldsets = (
        ('Service Info', {
            'fields': ('name', 'short_description', 'full_description', 'icon', 'icon_preview'),
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description', 'meta_keywords'),
        }),
    )


# 📝 Blog Admin
@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'thumbnail')
    search_fields = ('title',)
    list_filter = ('created_at',)
    readonly_fields = ('thumbnail',)

    def thumbnail(self, obj):
        if obj.image:
            return format_html(f'<img src="{obj.image.url}" width="100" style="border-radius:8px;" />')
        return "No Image"

    fieldsets = (
        ('Content', {
            'fields': ('title', 'content', 'image', 'thumbnail'),
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description', 'meta_keywords'),
        }),
    )


# 👔 Career Admin
@admin.register(Career)
class CareerAdmin(admin.ModelAdmin):
    list_display = ('title', 'location', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('title',)
    fieldsets = (
        ('Job Info', {
            'fields': ('title', 'description', 'location', 'apply_link', 'is_active'),
        }),
    )


# 📩 Lead Management Admin
@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'submitted_at')
    search_fields = ('name', 'email')
    readonly_fields = ('submitted_at',)


# 👥 Stakeholder Admin
@admin.register(Stakeholder)
class StakeholderAdmin(admin.ModelAdmin):
    list_display = ('title', 'image_preview')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return format_html(f'<img src="{obj.image.url}" width="100" style="border-radius:8px;" />')
        return "No Image"

    fieldsets = (
        ('Stakeholder Info', {
            'fields': ('title', 'description', 'image', 'image_preview'),
        }),
    )


# 📚 Resource Admin
@admin.register(Resource)
class ResourceAdmin(admin.ModelAdmin):
    list_display = ('title', 'date_added')
    search_fields = ('title',)
    fieldsets = (
        ('Resource Info', {
            'fields': ('title', 'description', 'file'),
        }),
        ('Meta', {
            'fields': ('date_added',),
        }),
    )
    readonly_fields = ('date_added',)


# 📞 Contact Info Admin
@admin.register(ContactInfo)
class ContactInfoAdmin(admin.ModelAdmin):
    list_display = ('email', 'phone')
    fieldsets = (
        ('Contact Details', {
            'fields': ('address', 'phone', 'email', 'map_embed_code'),
        }),
    )


# 🌟 Feature Admin
@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    list_display = ('title',)
    fieldsets = (
        ('Feature Info', {
            'fields': ('title', 'description', 'icon'),
        }),
    )
