from django.urls import path, include
from rest_framework import routers
from .views import (
    HomePageViewSet, AboutPageViewSet, ServiceViewSet, BlogViewSet,
    CareerViewSet, LeadViewSet, StakeholderViewSet, ResourceViewSet,
    ContactInfoViewSet, FeatureViewSet
)

router = routers.DefaultRouter()
router.register('home', HomePageViewSet)
router.register('about', AboutPageViewSet)
router.register('services', ServiceViewSet)
router.register('blogs', BlogViewSet)
router.register('careers', CareerViewSet)
router.register('leads', LeadViewSet)
router.register('stakeholders', StakeholderViewSet)
router.register('resources', ResourceViewSet)
router.register('contact', ContactInfoViewSet)
router.register('features', FeatureViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]
